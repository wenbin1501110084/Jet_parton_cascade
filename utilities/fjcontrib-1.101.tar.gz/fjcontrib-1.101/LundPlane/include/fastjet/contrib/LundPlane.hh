#ifndef __FASTJET_CONTRIB_LUNDPLANE_HH__
#define __FASTJET_CONTRIB_LUNDPLANE_HH__

// just include 
#include "fastjet/contrib/LundGenerator.hh"
#include "fastjet/contrib/LundWithSecondary.hh"
#include "fastjet/contrib/RecursiveLundEEGenerator.hh"

#endif // __FASTJET_CONTRIB_LUNDPLANE_HH__
